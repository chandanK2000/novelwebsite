import React from 'react'
import './Banner.css';
const Banner = () => {
  return (
    <div>
      <h3>this is banner page</h3>
    </div>
  )
}

export default Banner;
